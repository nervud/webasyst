<?php

class paymentShkeeperApi
{
    protected $api_url;
    protected $api_key;

    public function __construct($api_url, $api_key)
    {
        $this->api_url = rtrim($api_url, '/');
        $this->api_key = trim((string)$api_key);
    }

    protected function request($method, $endpoint, $data = array())
    {
        $url = $this->api_url . $endpoint;

        $ch = curl_init($url);

        $headers = array(
            'Content-Type: application/json',
            'X-Shkeeper-Api-Key: ' . $this->api_key,
        );

        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, strtoupper($method));
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 15);
        curl_setopt($ch, CURLOPT_TIMEOUT, 45);

        if (strtoupper($method) !== 'GET' && !empty($data)) {
            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
        }

        $response = curl_exec($ch);
        $http_code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $curl_error = curl_error($ch);

        curl_close($ch);

        if ($response === false || $curl_error) {
            return array(
                'ok' => false,
                'error' => 'cURL error: ' . $curl_error,
                'http_code' => $http_code,
                'raw' => null,
            );
        }

        $decoded = json_decode($response, true);

        return array(
            'ok' => ($http_code >= 200 && $http_code < 300),
            'http_code' => $http_code,
            'data' => is_array($decoded) ? $decoded : null,
            'raw' => $response,
        );
    }

    public function createInvoice($crypto, $amount, $order_id, $callback_url, $fiat = 'USD')
    {
        return $this->request('POST', "/api/v1/{$crypto}/payment_request", array(
            'external_id'  => (string)$order_id,
            'fiat'         => (string)$fiat,
            'amount'       => (string)$amount,
            'callback_url' => (string)$callback_url,
        ));
    }

    public function getInvoice($crypto, $order_id)
    {
        return $this->request('GET', "/api/v1/{$crypto}/payment_request/{$order_id}");
    }
}