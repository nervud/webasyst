<?php

return array(
    array(
        'title'       => 'Callback URL',
        'description' => 'Укажи этот URL в SHKeeper, если нужен callback вручную.',
        'value'       => '%HTTPS_RELAY_URL%?transaction_result=result',
    ),
);