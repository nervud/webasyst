<?php

return array(
    'api_url' => array(
        'title' => 'API URL',
        'description' => 'SHKeeper API URL',
        'value' => 'https://pay.vimpu.com',
    ),
    'api_key' => array(
        'title' => 'API Key',
        'description' => 'Your SHKeeper API key',
        'value' => 'HvWPwpihNxHVvjzz',
    ),
    'crypto' => array(
        'title' => 'Default crypto',
        'description' => 'Example: BTC, ETH-USDT',
        'value' => 'BTC',
    ),
    'rub_usd_rate' => array(
        'title' => 'RUB → USD rate',
        'description' => 'Например: 82.50',
        'value' => '82.50',
    ),
    'debug' => array(
        'title' => 'Debug',
        'description' => 'Enable logging',
        'value' => 1,
        'control_type' => waHtmlControl::CHECKBOX,
    ),
);