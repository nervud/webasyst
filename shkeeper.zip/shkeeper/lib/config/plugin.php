<?php

return array(
    'name'        => 'SHKeeper',
    'description' => 'Crypto payments via SHKeeper',
    'icon'        => 'img/shkeeper.png',
    'logo'        => 'img/shkeeper.png',
    'vendor'      => 'custom',
    'version'     => '0.1.1',
    'type'        => waPayment::TYPE_ONLINE,
);