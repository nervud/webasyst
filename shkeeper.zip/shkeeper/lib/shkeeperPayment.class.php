<?php

class shkeeperPayment extends waPayment
{
    protected $api;
    protected $order_id;
    protected $app_id;
    protected $merchant_id;

    public function init()
    {
        parent::init();

        waLog::log('SHKEEPER INIT START', 'payment/shkeeper.log');

        $this->api = new paymentShkeeperApi(
            $this->api_url,
            $this->api_key
        );

        waLog::log('SHKEEPER INIT DONE', 'payment/shkeeper.log');
    }

    /**
     * Валюта, в которой Shop-Script разрешает использовать этот способ оплаты.
     * Для текущего магазина фиксируем RUB.
     */
    public function allowedCurrency()
    {
        return array('RUB');
    }

    protected function convertRubToUsd($amount_rub)
    {
        $rate = (float)$this->rub_usd_rate;
        if ($rate <= 0) {
            $rate = 100;
        }

        $amount_usd = (float)$amount_rub / $rate;
        return number_format($amount_usd, 2, '.', '');
    }

    public function payment($payment_form_data, $order_data, $auto_submit = false)
    {
        waLog::log('SHKEEPER PAYMENT CALLED; ORDER=' . print_r($order_data, true), 'payment/shkeeper.log');

        $crypto = $this->crypto ? $this->crypto : 'BTC';

        $order_currency = !empty($order_data['currency_id']) ? strtoupper($order_data['currency_id']) : 'RUB';
        $order_amount = isset($order_data['amount']) ? (float)$order_data['amount'] : 0;

        waLog::log(
            'ORDER CURRENCY CHECK: order_currency=' . $order_currency . '; allowed=RUB',
            'payment/shkeeper.log'
        );

        if ($order_currency !== 'RUB') {
            waLog::log('ORDER CURRENCY NOT SUPPORTED', 'payment/shkeeper.log');
            return '<p>Этот способ оплаты сейчас поддерживает только валюту RUB.</p>';
        }

        // Для SHKeeper в MVP выставляем fiat=USD и конвертируем сумму из RUB в USD
        $fiat = 'USD';
        $amount_for_shkeeper = $this->convertRubToUsd($order_amount);

        $callback_url = $this->getRelayUrl() . '?transaction_result=result';

        waLog::log(
            'ORDER_AMOUNT=' . $order_amount .
            '; ORDER_CURRENCY=' . $order_currency .
            '; SHKEEPER_AMOUNT=' . $amount_for_shkeeper .
            '; SHKEEPER_FIAT=' . $fiat .
            '; CALLBACK_URL=' . $callback_url,
            'payment/shkeeper.log'
        );

        $invoice_response = $this->api->createInvoice(
            $crypto,
            $amount_for_shkeeper,
            $order_data['id'],
            $callback_url,
            $fiat
        );

        waLog::log('INVOICE RESPONSE: ' . print_r($invoice_response, true), 'payment/shkeeper.log');

        $invoice = array();
        if (!empty($invoice_response['data']) && is_array($invoice_response['data'])) {
            $invoice = $invoice_response['data'];
        }

        $view = wa()->getView();
        $view->assign('invoice_response', $invoice_response);
        $view->assign('invoice', $invoice);
        $view->assign('order', $order_data);
        $view->assign('crypto', $crypto);
        $view->assign('shkeeper_amount', $amount_for_shkeeper);
        $view->assign('shkeeper_fiat', $fiat);

        return $view->fetch($this->path . '/templates/payment.html');
    }

    protected function callbackInit($request)
    {
        waLog::log('SHKEEPER CALLBACK INIT: ' . print_r($request, true), 'payment/shkeeper.log');

        $external_id = waRequest::post('external_id', null, waRequest::TYPE_STRING);

        if (!$external_id) {
            $raw = file_get_contents('php://input');
            $json = json_decode($raw, true);
            if (is_array($json) && !empty($json['external_id'])) {
                $external_id = (string)$json['external_id'];
            }
        }

        $this->order_id = $external_id;
        $this->app_id = 'shop';

        waLog::log('SHKEEPER CALLBACK ORDER_ID=' . $this->order_id, 'payment/shkeeper.log');

        return parent::callbackInit($request);
    }

    protected function callbackHandler($request)
    {
        waLog::log('SHKEEPER CALLBACK HANDLER REQUEST: ' . print_r($request, true), 'payment/shkeeper.log');

        $header_api_key = waRequest::server('HTTP_X_SHKEEPER_API_KEY', '', waRequest::TYPE_STRING);
        $raw = file_get_contents('php://input');
        $json = json_decode($raw, true);

        waLog::log('SHKEEPER CALLBACK RAW: ' . $raw, 'payment/shkeeper.log');
        waLog::log('SHKEEPER CALLBACK HEADER KEY: ' . $header_api_key, 'payment/shkeeper.log');

        if ($header_api_key !== (string)$this->api_key) {
            waLog::log('SHKEEPER CALLBACK API KEY MISMATCH', 'payment/shkeeper.log');
            return array('result' => 0);
        }

        $external_id = waRequest::post('external_id', null, waRequest::TYPE_STRING);
        $status = waRequest::post('status', null, waRequest::TYPE_STRING);
        $amount = waRequest::post('amount', null, waRequest::TYPE_STRING);

        if (!$external_id && is_array($json)) {
            $external_id = isset($json['external_id']) ? $json['external_id'] : null;
            $status = isset($json['status']) ? $json['status'] : $status;
            $amount = isset($json['amount']) ? $json['amount'] : $amount;
        }

        waLog::log(
            'SHKEEPER CALLBACK external_id=' . print_r($external_id, true) .
            '; status=' . print_r($status, true) .
            '; amount=' . print_r($amount, true),
            'payment/shkeeper.log'
        );

        if (!$external_id) {
            return array('result' => 0);
        }

        $transaction_data = array(
            'order_id'      => $external_id,
            'plugin_txn_id' => $external_id,
            'amount'        => $amount,
            'currency_id'   => 'RUB',
            'native_id'     => $external_id,
        );

        if ($status === 'PAID' || $status === 'OVERPAID') {
            $result = $this->execAppCallback(self::CALLBACK_PAYMENT, $transaction_data);
            waLog::log('SHKEEPER CALLBACK PAYMENT RESULT: ' . print_r($result, true), 'payment/shkeeper.log');
            return $result;
        }

        return array('result' => 0);
    }
}